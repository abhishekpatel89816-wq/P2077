# P2077 Companion — Android Studio starter

A black/neon-green Android UI prototype built with Kotlin and Jetpack Compose.

## Open and build
1. Install Android Studio.
2. Extract this ZIP.
3. Open the `P2077_Companion` folder in Android Studio.
4. Let Gradle sync finish.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The APK output is usually at `app/build/outputs/apk/debug/app-debug.apk`.

## Important
This is a visual companion-app prototype only. The ESP/Aimbot/AM Kill/Headshot/
Teleport/Speed Hack switches are local UI demonstrations. They do not interact
with Free Fire, modify game memory, inject code, or bypass anti-cheat.
