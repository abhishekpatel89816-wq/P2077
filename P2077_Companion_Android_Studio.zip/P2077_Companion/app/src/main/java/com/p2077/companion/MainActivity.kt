package com.p2077.companion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070B09)
private val Panel = Color(0xFF101914)
private val Neon = Color(0xFF39FF14)
private val Muted = Color(0xFF9AA79D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { P2077App() }
    }
}

@Composable
fun P2077App() {
    var demoMode by remember { mutableStateOf(true) }
    val items = listOf(
        "ESP", "Aimbot", "AM Kill", "Headshot",
        "Teleport", "Speed Hack"
    )
    val states = remember { mutableStateMapOf<String, Boolean>() }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Neon,
        onPrimary = Color.Black, onBackground = Color.White,
        onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Spacer(Modifier.height(18.dp))
                    Text("P2077", color = Neon, fontSize = 36.sp,
                        fontWeight = FontWeight.Black)
                    Text("GAMING COMPANION", color = Muted,
                        fontSize = 11.sp, letterSpacing = 3.sp)
                }
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("CONTROL CENTER", color = Neon,
                                fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Visual demo interface", color = Color.White,
                                fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                "These switches only change their appearance in this app. " +
                                "They do not connect to or modify Free Fire.",
                                color = Muted, fontSize = 12.sp
                            )
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Demo mode", Modifier.weight(1f), color = Color.White)
                                Switch(checked = demoMode, onCheckedChange = { demoMode = it })
                            }
                        }
                    }
                }
                item {
                    Text("FEATURE PANEL", color = Neon,
                        fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                }
                items.forEach { name ->
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(name, color = Color.White,
                                        fontWeight = FontWeight.SemiBold)
                                    Text("UI preview only", color = Muted, fontSize = 11.sp)
                                }
                                Switch(
                                    checked = states[name] ?: false,
                                    onCheckedChange = { states[name] = it },
                                    enabled = demoMode
                                )
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF18251B))) {
                        Column(Modifier.padding(14.dp)) {
                            Text("NOTICE", color = Neon, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "P2077 is an unofficial visual companion concept. " +
                                "It provides no cheats, game injection, memory editing, " +
                                "or anti-cheat bypass.",
                                color = Muted, fontSize = 12.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text("P2077 • VERSION 1.0", Modifier.align(Alignment.CenterHorizontally),
                        color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}
